"""Figures 2 and 3 from results.json."""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({"font.family": "DejaVu Serif", "font.size": 9,
                     "axes.spines.top": False, "axes.spines.right": False})
res = json.load(open("results.json"))

# Figure 2
labels = ["Regional bank, low capacity", "Regional bank, high capacity", "National bank, high capacity"]
styles = [dict(color="#b2182b", marker="o", ls="-"),
          dict(color="#2166ac", marker="s", ls="--"),
          dict(color="#4d4d4d", marker="^", ls=":")]
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9))
for rows, lab, st in zip(res["exp2"]["lines"].values(), labels, styles):
    n = [q["n"] for q in rows]
    for a, key in zip(ax, ["loss_rate", "total"]):
        mean = np.array([q[key][0] for q in rows])
        ci = np.array([q[key][1] for q in rows])
        a.errorbar(n, mean, yerr=ci, capsize=2, lw=1.2, ms=4, label=lab, **st)
ax[0].set_xlabel("Number of connected partners")
ax[0].set_ylabel("Realised credit loss rate (%)")
ax[0].set_title("(a) Credit loss rate", fontsize=9)
ax[0].legend(frameon=False, fontsize=7.5, loc="upper left")
ax[1].set_xlabel("Number of connected partners")
ax[1].set_ylabel("Net monthly contribution (MU)")
ax[1].set_title("(b) Net contribution", fontsize=9)
ax[1].axhline(0, color="grey", lw=0.6)
fig.tight_layout()
fig.savefig("fig2.png", dpi=300)

# Figure 3
sw = res["exp3"]["sweep"]
eta = [s["eta"] for s in sw]
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.8))
ax[0].plot(eta, [s["obj"] for s in sw], "k-o", ms=3.5, lw=1.2)
ax[0].axvspan(0.20, 0.30, color="0.9")
ax[0].text(0.205, ax[0].get_ylim()[0] + 1, "20–30%\nrange", fontsize=7)
ax[0].set_xlabel("Governance effectiveness η")
ax[0].set_ylabel("Optimal profit Π*(η) (MU)")
ax[0].set_title("(a) Optimal value", fontsize=9)
ax[1].step(eta, [s["gross"] for s in sw], "k-", where="post", lw=1.2)
ax[1].set_xlabel("Governance effectiveness η")
ax[1].set_ylabel("B(z*) (MU)")
ax[1].set_title("(b) Risk load and network size", fontsize=9)
ax2 = ax[1].twinx()
ax2.step(eta, [s["n"] for s in sw], color="#2166ac", ls="--", where="post", lw=1.2)
ax2.set_ylabel("Partners selected |S*|", color="#2166ac")
ax2.set_yticks([3, 4, 5, 6])
ax2.spines["top"].set_visible(False)
fig.tight_layout()
fig.savefig("fig3.png", dpi=300)
print("Saved fig2.png and fig3.png")
