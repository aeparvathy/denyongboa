"""Online matching policies and the four numerical experiments (Section 6)."""
import json
import time

import numpy as np

from model import (CGOV, DELTA, ETA, E, J, K, PARTNERS, allowed,
                   best_strategy, fluid_lp, lgd, m, p, pd0, segments,
                   strategic_milp, true_values, x, base_params)

# matching capability: (theta, s) = (risk differentiation, log-error std)
CAP = {"full": (1.0, 0.0), "high": (1.0, 0.15), "low": (0.0, 0.50)}


def estimates(P, cap, rng):
    theta, s = CAP[cap]
    if s > 0:
        err_p = np.exp(rng.normal(-s * s / 2, s, size=(E, K)))
        err_d = np.exp(rng.normal(-s * s / 2, s, size=(J, E, K)))
    else:
        err_p, err_d = np.ones((E, K)), np.ones((J, E, K))
    phat = np.minimum(np.broadcast_to(p * err_p, (J, E, K)).copy(), 0.95)
    pdhat = np.minimum((P["beta"][:, None, None] ** theta) * pd0[None] * err_d, 0.5)
    vhat = (1 - P["sigma"])[:, None, None] * m - pdhat * (lgd * x)
    return phat, pdhat, vhat


def ranked_offers(P, S, phat, vhat, mu, rule):
    segs, n = segments(P)
    lists = {}
    for si, (j, e, s) in enumerate(segs):
        if j not in S:
            continue
        a = allowed(P, j, s)
        cand = []
        for k in range(K):
            if not a[k] or phat[j, e, k] <= 0:
                continue
            if rule == "bid":
                score = phat[j, e, k] * (vhat[j, e, k] - mu * x[k])
                if score > 0:
                    cand.append((score, k))
            else:  # risk-blind greedy: bank margin only
                cand.append((phat[j, e, k] * (1 - P["sigma"][j]) * m[k], k))
        lists[si] = [k for _, k in sorted(cand, reverse=True)]
    return segs, n, lists


def simulate(P, S, cap, rule, rng, learn=False, n0=30.0, resolve=10):
    pd_true, _ = true_values(P)
    phat, _, vhat = estimates(P, cap, rng)
    _, mu, _ = fluid_lp(P, S, phat, vhat)
    segs, n, lists = ranked_offers(P, S, phat, vhat, mu, rule)

    ev_seg, ev_t = [], []
    for si in lists:
        c = rng.poisson(n[si])
        ev_seg.append(np.full(c, si))
        ev_t.append(rng.random(c))
    ev_seg, ev_t = np.concatenate(ev_seg), np.concatenate(ev_t)
    order = np.argsort(ev_t)
    ev_seg, ev_t = ev_seg[order], ev_t[order]
    u_acc, u_def = rng.random(len(ev_seg)), rng.random(len(ev_seg))

    rem = P["R"]
    margin = loss = el = expo = 0.0
    n_acc = 0
    if learn:  # Beta posteriors on acceptance, shared across partners
        a_, b_ = n0 * phat[0].copy(), n0 * (1 - phat[0])
    checkpoints = [c / resolve for c in range(1, resolve)] if (rule == "bid" and resolve) else []
    ci = 0

    for t, si in enumerate(ev_seg):
        if ci < len(checkpoints) and ev_t[t] >= checkpoints[ci]:
            tau = checkpoints[ci]
            ci += 1
            Pc = dict(P, R=rem, lam=P["lam"] * (1 - tau))
            pcur = np.broadcast_to(a_ / (a_ + b_), (J, E, K)) if learn else phat
            _, mu, _ = fluid_lp(Pc, S, pcur, vhat)
            if not learn:
                _, _, lists = ranked_offers(P, S, phat, vhat, mu, rule)

        j, e, s = segs[si]
        k = -1
        if learn:
            a, best = allowed(P, j, s), 0.0
            for kk in range(K):
                if a[kk] and phat[j, e, kk] > 0 and x[kk] <= rem:
                    score = rng.beta(a_[e, kk], b_[e, kk]) * (vhat[j, e, kk] - mu * x[kk])
                    if score > best:
                        best, k = score, kk
        else:
            for kk in lists[si]:
                if x[kk] <= rem:
                    k = kk
                    break
        if k < 0:
            continue

        accepted = u_acc[t] < p[e, k]
        if learn:
            a_[e, k] += accepted
            b_[e, k] += 1 - accepted
        if accepted:
            n_acc += 1
            margin += (1 - P["sigma"][j]) * m[k]
            if x[k] > 0:
                rem -= x[k]
                expo += x[k]
                el += pd_true[j, e, k] * lgd[k] * x[k]
                if u_def[t] < pd_true[j, e, k]:
                    loss += lgd[k] * x[k]

    return dict(margin=margin, loss=loss, el=el, expo=expo, net=margin - loss,
                acc=n_acc, events=len(ev_seg))


def fixed_terms(P, S, h):
    B = sum(P["L"][j] for j in S) + P["kappa"] * len(S) * (len(S) - 1) / 2
    data = DELTA * sum(P["lam"][j] * P["rho"][j] for j in S)
    return data - sum(P["F"][j] for j in S) - (1 - ETA[h]) * B - CGOV[h]


def mean_ci(vals):
    a = np.array(vals)
    return float(a.mean()), float(1.96 * a.std(ddof=1) / np.sqrt(len(a)))


def exp1(reps=200, seed=1):
    """Matching policies on the optimal network (Table 5)."""
    P = base_params()
    best, _ = best_strategy(P)
    S, h = best["S"], best["h"]
    ub, mu, _ = fluid_lp(P, S)
    const = fixed_terms(P, S, h)
    policies = [("Risk-blind greedy (high-capability estimates)", "high", "greedy", False),
                ("Bid-price, low capability", "low", "bid", False),
                ("Bid-price, low capability + Layer-5 learning", "low", "bid", True),
                ("Bid-price, high capability", "high", "bid", False),
                ("Bid-price, full information", "full", "bid", False)]
    rows = []
    for name, cap, rule, learn in policies:
        rng = np.random.default_rng(seed)
        rs = [simulate(P, S, cap, rule, rng, learn) for _ in range(reps)]
        row = dict(policy=name)
        for key in ["margin", "loss", "net", "expo"]:
            row[key] = mean_ci([r[key] for r in rs])
        row["loss_rate"] = mean_ci([100 * r["loss"] / max(r["expo"], 1e-9) for r in rs])
        row["total"] = (row["net"][0] + const, row["net"][1])
        row["pct_ub"] = 100 * row["net"][0] / ub
        rows.append(row)
    return dict(S=S, h=h, ub=ub, mu=mu, const=const, rows=rows, milp=best,
                events=rs[0]["events"])


def exp2(reps=100, seed=2):
    """Adding partners in order of stand-alone value (Figure 2)."""
    P0 = base_params()
    best, _ = best_strategy(P0)
    order = sorted(range(J), key=lambda j: -strategic_milp(P0, best["h"], force=[j])["obj"])
    banks = {"Regional, low capacity (θ=0, s=0.5, h=0)": (False, "low", 0),
             "Regional, high capacity (θ=1, s=0.15, h=2)": (False, "high", 2),
             "National, high capacity (θ=1, s=0.15, h=2)": (True, "high", 2)}
    lines = {}
    for name, (national, cap, h) in banks.items():
        P = base_params(national=national)
        rows = []
        for size in range(1, J + 1):
            S = order[:size]
            rng = np.random.default_rng(seed + size)
            rs = [simulate(P, S, cap, "bid", rng) for _ in range(reps)]
            const = fixed_terms(P, S, h)
            B = sum(P["L"][j] for j in S) + P["kappa"] * size * (size - 1) / 2
            rows.append(dict(n=size,
                             loss_rate=mean_ci([100 * r["loss"] / max(r["expo"], 1e-9) for r in rs]),
                             el_rate=mean_ci([100 * r["el"] / max(r["expo"], 1e-9) for r in rs]),
                             total=mean_ci([r["net"] + const for r in rs]),
                             oploss=(1 - ETA[h]) * B))
        lines[name] = rows
    return dict(order=[PARTNERS[j][0] for j in order], lines=lines)


def exp3():
    """Governance levels, interdependence loss and continuous effectiveness (Table 6, Figure 3)."""
    grid = []
    for kappa in [0.5, 1.0, 2.0]:
        P = base_params(kappa=kappa)
        for h in range(len(ETA)):
            d = strategic_milp(P, h)
            grid.append(dict(kappa=kappa, h=h, n=len(d["S"]), S=d["S"], obj=d["obj"],
                             oploss=d["oploss"], gross=d["gross_oploss"]))
    P = base_params()
    sweep = []
    for eta in np.round(np.arange(0, 0.61, 0.05), 2):
        d = strategic_milp(P, 0, eta=float(eta))
        sweep.append(dict(eta=float(eta), n=len(d["S"]), S=d["S"], obj=d["obj"],
                          gross=d["gross_oploss"]))
    return dict(grid=grid, sweep=sweep)


def exp4():
    """Scaling platform fee shares (Table 7)."""
    rows = []
    for t in [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]:
        b, _ = best_strategy(base_params(sigma_mult=t))
        rows.append(dict(sm=t, h=b["h"], n=len(b["S"]), S=b["S"], obj=b["obj"],
                         fees=b["fees"], margin=b["margin"], fee_base=b["fees"] / t))
    return rows


if __name__ == "__main__":
    t0 = time.time()
    res = dict(exp1=exp1())
    print(f"Experiment 1 done ({time.time() - t0:.0f} s)")
    res["exp2"] = exp2()
    print(f"Experiment 2 done ({time.time() - t0:.0f} s)")
    res["exp3"], res["exp4"] = exp3(), exp4()
    with open("results.json", "w") as f:
        json.dump(res, f, indent=1, default=float)

    e1 = res["exp1"]
    print(f"\nOptimal network: {[PARTNERS[j][0] for j in e1['S']]}, governance level {e1['h']}")
    print(f"Profit {e1['milp']['obj']:.1f} MU, fluid bound {e1['ub']:.1f} MU, bid price {e1['mu']:.4f}")
    for r in e1["rows"]:
        print(f"  {r['policy']:<48s} {r['pct_ub']:5.1f}% of bound, loss rate {r['loss_rate'][0]:.1f}%")
