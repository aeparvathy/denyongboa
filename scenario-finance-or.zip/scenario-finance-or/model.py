"""Two-level model for scenario-based bank-platform integration.

Strategic level: partner selection and governance level (MILP).
Operational level: offer matching under a credit-exposure budget (fluid LP).
Units: 1 MU = 1,000 CNY, one-month horizon. Parameter values are illustrative.
"""
import itertools

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, linprog, milp

EVENTS = ["Flight booking", "Hotel booking", "Large online purchase",
          "Car purchase deposit", "Rent payment", "Tuition payment"]
PRODUCTS = ["Insurance", "FX / cross-border card", "Instalment credit",
            "Auto loan", "Wealth product"]
E, K = len(EVENTS), len(PRODUCTS)
CREDIT = np.array([0, 0, 1, 1, 0], bool)

m = np.array([0.03, 0.02, 0.30, 2.00, 0.15])   # margin per accepted offer
x = np.array([0.0, 0.0, 8.0, 80.0, 0.0])       # exposure per accepted offer
lgd = np.array([0.0, 0.0, 0.60, 0.35, 0.0])

# acceptance probability p[e, k]
p = np.array([
    [0.12, 0.05, 0.02, 0.00, 0.005],
    [0.06, 0.03, 0.02, 0.00, 0.005],
    [0.01, 0.01, 0.10, 0.00, 0.005],
    [0.02, 0.00, 0.03, 0.08, 0.005],
    [0.00, 0.00, 0.04, 0.00, 0.010],
    [0.00, 0.04, 0.06, 0.00, 0.010]])

# base default probability before the partner multiplier
pd0 = np.zeros((E, K))
pd0[:, 2] = [0.010, 0.012, 0.020, 0.015, 0.030, 0.025]
pd0[3, 3] = 0.015

# name, events/month, event mix, consent, fee share, risk mult., local share,
# fixed cost, operational loss, eligible products
PARTNERS = [
    ("OTA-A (national travel)",      18000, [.55, .45, 0, 0, 0, 0], .40, .35, 1.0, .15, 6.0, 8.0, [0, 1, 2]),
    ("OTA-B (regional travel)",       7500, [.40, .60, 0, 0, 0, 0], .50, .20, 1.1, .60, 3.0, 4.8, [0, 1, 2]),
    ("E-com-A (national market)",    27000, [0, 0, 1, 0, 0, 0],     .30, .40, 1.2, .15, 7.5, 11.2, [0, 2]),
    ("E-com-B (local group-buying)", 12000, [0, 0, 1, 0, 0, 0],     .45, .25, 2.5, .70, 3.0, 6.4, [0, 2]),
    ("Auto marketplace",              3600, [0, 0, 0, 1, 0, 0],     .50, .30, 1.0, .30, 4.5, 5.6, [0, 2, 3]),
    ("Rental platform",               6000, [0, 0, 0, 0, 1, 0],     .40, .20, 1.6, .50, 3.0, 4.8, [2, 4]),
    ("Education platform",            4500, [0, 0, 0, 0, 0, 1],     .45, .25, 1.3, .50, 3.0, 4.0, [1, 2, 4]),
    ("Payment super-app",            24000, [.15, .10, .45, .05, .15, .10], .25, .45, 1.3, .15, 9.0, 16.0, [0, 1, 2, 3, 4]),
]
J = len(PARTNERS)

DELTA = 0.002                   # data value per consented event
ETA = [0.00, 0.10, 0.18, 0.25]  # loss reduction by governance level
CGOV = [0.0, 1.5, 3.5, 6.0]     # governance cost by level
KAPPA = 1.0                     # loss per connected pair of partners
R = 3500.0                      # monthly budget for new credit exposure


def base_params(sigma_mult=1.0, national=False, kappa=KAPPA):
    col = lambda i: np.array([q[i] for q in PARTNERS], float)
    P = dict(lam=col(1), mix=np.array([q[2] for q in PARTNERS], float),
             rho=col(3), sigma=np.minimum(col(4) * sigma_mult, 0.95),
             beta=col(5), omega=np.ones(J) if national else col(6),
             F=col(7), L=col(8), kappa=kappa, R=R)
    elig = np.zeros((J, K), bool)
    for j, q in enumerate(PARTNERS):
        elig[j, q[9]] = True
    P["elig"] = elig
    return P


def true_values(P):
    pd = np.minimum(P["beta"][:, None, None] * pd0[None], 0.5)
    v = (1 - P["sigma"])[:, None, None] * m - pd * (lgd * x)
    return pd, v


def segments(P):
    # s = 0: local customers (credit allowed); s = 1: non-local (no credit)
    segs, n = [], []
    for j in range(J):
        for e in range(E):
            base = P["lam"][j] * P["mix"][j, e] * P["rho"][j]
            if base <= 0:
                continue
            for s, share in ((0, P["omega"][j]), (1, 1 - P["omega"][j])):
                if share > 0:
                    segs.append((j, e, s))
                    n.append(base * share)
    return segs, np.array(n)


def allowed(P, j, s):
    a = P["elig"][j].copy()
    if s == 1:
        a &= ~CREDIT
    return a


def fluid_lp(P, S, phat=None, vhat=None):
    """Solve the fluid matching LP for partner set S. Returns value, bid price, y."""
    if phat is None:
        phat = np.broadcast_to(p, (J, E, K))
    if vhat is None:
        _, vhat = true_values(P)
    segs, n = segments(P)
    idx, c, expo = [], [], []
    for si, (j, e, s) in enumerate(segs):
        if j not in S:
            continue
        a = allowed(P, j, s)
        for k in range(K):
            if a[k] and phat[j, e, k] > 0:
                idx.append((si, k))
                c.append(n[si] * phat[j, e, k] * vhat[j, e, k])
                expo.append(n[si] * phat[j, e, k] * x[k])
    if not idx:
        return 0.0, 0.0, {}
    nv = len(idx)
    A_ub, b_ub = [], []
    for si in sorted({si for si, _ in idx}):
        A_ub.append([1.0 if idx[t][0] == si else 0.0 for t in range(nv)])
        b_ub.append(1.0)
    A_ub.append(expo)
    b_ub.append(P["R"])
    res = linprog(-np.array(c), A_ub=np.array(A_ub), b_ub=b_ub,
                  bounds=[(0, 1)] * nv, method="highs")
    mu = max(-res.ineqlin.marginals[-1], 0.0)
    y = {(segs[idx[t][0]], idx[t][1]): res.x[t] for t in range(nv) if res.x[t] > 1e-9}
    return -res.fun, mu, y


def strategic_milp(P, h, force=None, eta=None):
    """Partner selection MILP for governance level h.
    force: fixed partner set; eta: continuous governance effectiveness (no cost)."""
    _, v = true_values(P)
    segs, n = segments(P)
    eff = ETA[h] if eta is None else eta
    idx, c_y, expo = [], [], []
    for si, (j, e, s) in enumerate(segs):
        a = allowed(P, j, s)
        for k in range(K):
            if a[k] and p[e, k] > 0:
                idx.append((si, k))
                c_y.append(n[si] * p[e, k] * v[j, e, k])
                expo.append(n[si] * p[e, k] * x[k])
    pairs = list(itertools.combinations(range(J), 2))
    nz, ny, nw = J, len(idx), len(pairs)
    N = nz + ny + nw

    c = np.zeros(N)
    c[:nz] = DELTA * P["lam"] * P["rho"] - P["F"] - (1 - eff) * P["L"]
    c[nz:nz + ny] = c_y
    c[nz + ny:] = -(1 - eff) * P["kappa"]

    rows, lb, ub = [], [], []
    for si in sorted({si for si, _ in idx}):
        r = np.zeros(N)
        for t, (sj, _) in enumerate(idx):
            if sj == si:
                r[nz + t] = 1
        r[segs[si][0]] = -1
        rows.append(r); lb.append(-np.inf); ub.append(0)
    r = np.zeros(N)
    r[nz:nz + ny] = expo
    rows.append(r); lb.append(-np.inf); ub.append(P["R"])
    for q, (a_, b_) in enumerate(pairs):
        r = np.zeros(N)
        r[nz + ny + q], r[a_], r[b_] = 1, -1, -1
        rows.append(r); lb.append(-1); ub.append(np.inf)

    lo, hi = np.zeros(N), np.ones(N)
    hi[nz + ny:] = np.inf
    if force is not None:
        for j in range(J):
            lo[j] = hi[j] = float(j in force)
    integ = np.zeros(N)
    integ[:nz] = 1
    res = milp(-c, constraints=LinearConstraint(np.array(rows), lb, ub),
               integrality=integ, bounds=Bounds(lo, hi))

    S = [j for j in range(J) if round(res.x[j])]
    y = res.x[nz:nz + ny]
    js = [segs[si][0] for si, _ in idx]
    es = [segs[si][1] for si, _ in idx]
    ks = [k for _, k in idx]
    ns = [n[si] for si, _ in idx]
    fees = sum(ns[t] * p[es[t], ks[t]] * P["sigma"][js[t]] * m[ks[t]] * y[t] for t in range(ny))
    margin = sum(ns[t] * p[es[t], ks[t]] * (1 - P["sigma"][js[t]]) * m[ks[t]] * y[t] for t in range(ny))
    credit_loss = margin - float(np.dot(c_y, y))
    B = sum(P["L"][j] for j in S) + P["kappa"] * len(S) * (len(S) - 1) / 2
    return dict(h=h, S=S, obj=-res.fun - (CGOV[h] if eta is None else 0.0),
                margin=margin, credit_loss=credit_loss, fees=fees,
                gross_oploss=B, oploss=(1 - eff) * B,
                data=DELTA * sum(P["lam"][j] * P["rho"][j] for j in S),
                fixed=sum(P["F"][j] for j in S), gov=CGOV[h],
                exposure=float(np.dot(expo, y)))


def best_strategy(P):
    sols = [strategic_milp(P, h) for h in range(len(ETA))]
    return max(sols, key=lambda d: d["obj"]), sols
